﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace LogXExplorer.Module.comm
{
    [ServiceContract]
    public interface ILogXPrivateServices
    {
        //minden amit kliens-server kommunikációval akarsz híni, itt kell először deklarálni.
        //ide kell tenni valamennyi konkurrens hivast.

        //Teszt
        [OperationContract]
        String DoWork(String param1, String param2);


        //Tárolóhely státusz állítás
        [OperationContract]
        bool ChangeLocationStatus(Int32 LocationID, Int32 status);


        //Bizonylat státusz állítás
        [OperationContract]
       void ChangeCommonTrHeaderStatus(Int32 CtrhID, Int32 status);

        void CreateTransportOrder(bool back, int ctrH, int ctrd, int lc, byte targetTag, byte Tipus, int InOut, int IocpId);

        //Új transport order ID
        [OperationContract]
        ushort GetNewSorszam(string commonType);
    }
}
