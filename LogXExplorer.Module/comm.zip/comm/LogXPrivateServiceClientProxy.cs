﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace LogXExplorer.Module.comm
{
    class LogXPrivateServiceClientProxy : ClientBase<ILogXPrivateServices>, ILogXPrivateServices
    {
        //Teszt
        public string DoWork(String param1, String param2)
        {
            return base.Channel.DoWork(param1, param2);
        }


        //Tárolóhely státusz állítás
        public bool ChangeLocationStatus(Int32 LocationID, Int32 status)
        {
            return base.Channel.ChangeLocationStatus(LocationID, status);
        }


        //Bizonylat státusz állítás
        public void ChangeCommonTrHeaderStatus(Int32 CtrhID, Int32 status)
        {
            base.Channel.ChangeCommonTrHeaderStatus(CtrhID, status);
        }


        public void CreateTransportOrder(bool back, int ctrH, int ctrd, int lc, byte targetTag, byte Tipus, int InOut, int IocpId)
        {
            base.Channel.CreateTransportOrder(back,ctrH, ctrd,lc,targetTag,Tipus,InOut,IocpId);

        }

        public ushort GetNewSorszam(string commomnType)
        {
            return base.Channel.GetNewSorszam(commomnType);
        }
    }
}
